#include <stdio.h>
#include <stdlib.h>
#include <GL/glut.h>
#include <math.h>

#define WINDOW_W 1536
#define WINDOW_H 786
#define mapX 8
#define mapY 8
#define mapS mapX*mapY

//Movement characteristics
#define turnSens 5.0
#define moveSpeed 3.0

float playerX = 0;
float playerY = 0;
float playerAngle = 0;
float playerDeltaX = 0;
float playerDeltaY = 0;

char map[]=
{
	'W','W','W','W','W','W','W','W',
	'W','O','O','O','O','O','O','W',
	'W','O','W','O','O','O','O','W',
	'W','O','O','I','O','O','O','W',
	'W','O','O','O','I','O','O','W',
	'W','O','O','O','O','W','O','W',
	'W','O','O','O','O','O','O','W',
	'W','W','W','W','W','W','W','W',
};

//Fix to a value between 0-359 if over or under
float fixAngle(float angle)
{
 	if(angle > 359)
 	{
 		angle -= 360;
 	}
 	else if(angle < 0)
 	{
 		angle += 360;
 	}
 	return angle;
}

float degToRad(float angle)
{
	return (angle * M_PI) / 180.0;
}

float dist(float ax, float bx, float ay, float by, float ang)
{
	return sqrt((bx-ax)*(bx-ax) + (by-ay)*(by-ay));
	//return cos(degToRad(ang))*(bx-ax) - sin(degToRad(ang))*(by-ay); //The cos of this distance gets rid of the fisheye
}

void Buttons(unsigned char key,int x,int y)
{
 if(key == 'a')
 {
 	playerAngle += turnSens; 
 	playerAngle = fixAngle(playerAngle);
 	playerDeltaX = cos(degToRad(playerAngle)); //math.h uses radians
 	playerDeltaY = -sin(degToRad(playerAngle));
 }
 if(key == 'd')
 { 
 	playerAngle -= turnSens;
 	playerAngle = fixAngle(playerAngle);
 	playerDeltaX = cos(degToRad(playerAngle)); //math.h uses radians
 	playerDeltaY = -sin(degToRad(playerAngle));
 } 
 if(key == 'w')
 { 
 	playerX += playerDeltaX * moveSpeed;
 	playerY += playerDeltaY * moveSpeed;
 }
 if(key == 's')
 { 
 	playerX -= playerDeltaX * moveSpeed;
 	playerY -= playerDeltaY * moveSpeed;
 }
 
 glutPostRedisplay();
}


void drawRays2D()
{
	int rayNum = 0;
	int mY = 0;//coordinates on map
	int mX = 0;//
	int mP = 0;//map array position
	int mPV = 0;//map array position vertical temp
	
	float FOV = 90;
	float rayX = 0; //These will become where the ray intersects a wall
	float rayY = 0; //
	float xOffset = 0;
	float yOffset = 0;
	float vertX = 0;//Coordinates to compare vertical and horizontal intersections
	float vertY = 0;//
	
	float rayAngle = fixAngle(playerAngle+(FOV*0.5));
	//float rayAngle = fixAngle(playerAngle);
	
    for(rayNum = 0; rayNum < FOV; rayNum++)//draw this number of rays
	{
		int depthOfField = 0;
		float distV = 99999999;//distance to vertical intersection
		float distW = 99999999;//distance to horizontal intersection
		
		//Check for verticalal ray intersections
		float angleTan = tan(degToRad(rayAngle));
		if(cos(degToRad(rayAngle)) < -0.001) //Looking right
		{
			rayX = (((int)playerX>>6)<<6)-0.0001;
			rayY = (playerX - rayX) * angleTan + playerY;
			xOffset = -64;
			yOffset = -xOffset * angleTan;
		}
		else if(cos(degToRad(rayAngle)) > 0.001) //Looking left
		{
			rayX = (((int)playerX>>6)<<6)+64;                                          ///////64 values should probably be separate tileSize variable or mapS for easier conversion
			rayY = (playerX - rayX) * angleTan + playerY;
			xOffset = 64;
			yOffset = -xOffset * angleTan;
		}
		else //Looking straight up or down, no vertical intersection
		{
			rayX = playerX;
			rayY = playerY;
			depthOfField = 8;
		}
		while(depthOfField < 8)
		{
			mX = (int)(rayX)>>6; //put in nice integer form for array coordinates
			mY = (int)(rayY)>>6; //put in nice integer form for array coordinates
			mPV = mY*mapX+mX;
			if(mPV > 0 && mPV < mapX*mapY && (map[mPV] == 'W' || map[mPV] == 'I')) //Found a wall
			{
				depthOfField = 8;
				distV = dist(playerX, rayX, playerY, rayY, rayAngle);
			}
			else //go check the next horizontal
			{
				rayX += xOffset;
				rayY += yOffset;
				depthOfField++;
			}
		}
		vertX = rayX;
		vertY = rayY;
		
        //Check for horizontal ray intersections
		angleTan = 1/angleTan;
		depthOfField = 0;
		if(sin(degToRad(rayAngle)) > 0.001) //Looking up
		{
			rayY = (((int)playerY>>6)<<6)-0.0001;
			rayX = (playerY - rayY) * angleTan + playerX;
			yOffset = -64;
			xOffset = -yOffset * angleTan;
		}
		else if(sin(degToRad(rayAngle)) < -0.001) //Looking down
		{
			rayY = (((int)playerY>>6)<<6)+64;                                          ///////64 values should probably be separate tileSize variable or mapS?
			rayX = (playerY - rayY) * angleTan + playerX;
			yOffset = 64;
			xOffset = -yOffset * angleTan;
		}
		else //Looking straight left or right, no horizontal intersection
		{
			rayX = playerX;
			rayY = playerY;
			depthOfField = 8;
		}
		while(depthOfField < 8)
		{
			mX = (int)(rayX)>>6; //put in nice integer form for array coordinates
			mY = (int)(rayY)>>6; //put in nice integer form for array coordinates
			mP = mY*mapX+mX;
			if(mP > 0 && mP < mapX*mapY && (map[mP] == 'W' || map[mP] == 'I')) //Found a wall
			{
				depthOfField = 8;
				distW = dist(playerX, rayX, playerY, rayY, rayAngle);
			}
			else //go check the next horizontal
			{
				rayX += xOffset;
				rayY += yOffset;
				depthOfField++;
			}
		}
		
		//Ray coordinates are set to horizontal now, if vertical is closer, set that
		if(distV < distW)
		{
			rayX = vertX;
			rayY = vertY;	
			distW = distV;	
			mP = mPV;	
		}
		
		//Draw "3D" walls
		float angleDiff = fixAngle(playerAngle - rayAngle);
		distW = distW*cos(degToRad(angleDiff));
		
		float wallHeight = (mapS*680)/distW;
		if(wallHeight > 680) wallHeight = 680;
		
		float lineOffset = WINDOW_H/2 - wallHeight/2;
		if(map[mP] == 'I') glColor3f(0,0,wallHeight/680);
		else glColor3f(0,wallHeight/680,0);
		glLineWidth(8);
		glBegin(GL_LINES);
		 glVertex2i(rayNum*8+520, lineOffset); //bottom of the wall, shifted right of the "minimap" and into the middle of the screen
		 glVertex2i(rayNum*8+520, wallHeight+lineOffset); //top of the wall
		glEnd();
		
		//Draw a green ray out from player FOV to walls on minimap
		glColor3f(0,1,0);
		glLineWidth(1);
		glBegin(GL_LINES);
		 glVertex2i(playerX, playerY);
		 glVertex2i(rayX, rayY); //ray intersect positions
		glEnd();
		
		
		rayAngle--; //iterate for next ray in FOV
	}
}


void init(void)
{
 glClearColor(0.3, 0.3, 0.3, 0.0); //Gray background
 gluOrtho2D(0, WINDOW_W, WINDOW_H, 0);//Set up coordinate system
 playerX = 100; //Player starting position
 playerY = 100;
 playerAngle = 1.5;
 playerDeltaX = cos(degToRad(playerAngle)); //math.h uses radians
 playerDeltaY = -sin(degToRad(playerAngle));
}


void draw2DMap()
{
	int xOffset = 0;
	int yOffset = 0;
	int y = 0;
	int x = 0;
	int tileSize = mapS;
	for(y = 0; y < mapY; y++)//Loop through every coordinate
	{
		for(x = 0; x < mapX; x++)
		{
			if(map[y*mapX+x] == 'O')//Draw a space
			{
				glColor3f(0,0,0);//Black floors (epmty space)
			}
			else//Draw a wall
			{
				glColor3f(1,1,1);//White walls
			}
			xOffset = x*tileSize;
			yOffset = y*tileSize;
			glBegin(GL_QUADS);//Draw a quadrilateral for the space
			 glVertex2i(xOffset, yOffset);
			 glVertex2i(xOffset, yOffset+tileSize);
			 glVertex2i(xOffset+tileSize, yOffset+tileSize);
			 glVertex2i(xOffset+tileSize, yOffset);
			glEnd();
		}
	}
}


void drawPlayer()
{
 glColor3f(1,1,0); //Yellow
 glPointSize(8); //Set dot size
 glBegin(GL_POINTS); //Display a dot at the player coordinates
 glVertex2i(playerX, playerY);
 glEnd();
 
 glBegin(GL_LINES);  
  glVertex2i(playerX, playerY);
  glVertex2i(playerX + playerDeltaX * 20, playerY + playerDeltaY * 20); 
 glEnd();
}


void display( void )
{                  
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);//Clear the window to redraw the next frame
  draw2DMap();
  drawPlayer();
  drawRays2D();
  
  glutSwapBuffers();
}


void main(int argc, char** argv)
{
  glutInit(&argc,argv);
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
  glutInitWindowSize(WINDOW_W, WINDOW_H);
  glutCreateWindow("Raycaster Demo");//Window title
  init();//Setup the window
  glutDisplayFunc(display);//tell OpenGL main loop what to use to display
  glutKeyboardFunc(Buttons);//tel OpenGL what to check for key presses
  glutMainLoop();//Pass control to the main OpenGL loop
}
